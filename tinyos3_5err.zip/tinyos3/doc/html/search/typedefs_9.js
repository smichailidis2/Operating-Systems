var searchData=
[
  ['vm_5fconfig_590',['vm_config',['../bios_8h.html#a78f20592af397bf72970300f0e8dba4d',1,'bios.h']]]
];
