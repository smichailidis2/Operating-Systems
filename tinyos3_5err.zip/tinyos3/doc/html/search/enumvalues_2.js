var searchData=
[
  ['dev_5fmax_604',['DEV_MAX',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a4d07dfbc7e68d26e2d92773a37381ce7',1,'kernel_dev.h']]],
  ['dev_5fnull_605',['DEV_NULL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a8ca9ed7c2fc080b6706582ccf828b08f',1,'kernel_dev.h']]],
  ['dev_5fserial_606',['DEV_SERIAL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90adb43c91cf279ccd4510abaed9425bacc',1,'kernel_dev.h']]]
];
