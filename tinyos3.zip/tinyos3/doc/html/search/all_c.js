var searchData=
[
  ['macros_20for_20checking_20system_20calls_2e_154',['Macros for checking system calls.',['../group__check__macros.html',1,'']]],
  ['main_5ftask_155',['main_task',['../structprocinfo.html#a4da339065f8780b37ab788f18ef9ed20',1,'procinfo::main_task()'],['../structprocess__control__block.html#a7d4ddbf8f67ac2bfe9774796b818354e',1,'process_control_block::main_task()']]],
  ['main_5fthread_156',['main_thread',['../structprocess__control__block.html#a3b7a2a952ec5c19d7331307639c78482',1,'process_control_block']]],
  ['max_5fcores_157',['MAX_CORES',['../bios_8h.html#a009855593b59738d24dbfc236edb3b14',1,'bios.h']]],
  ['max_5ffileid_158',['MAX_FILEID',['../group__syscalls.html#ga9c697bf9e856897ad75f28190a6f0b68',1,'tinyos.h']]],
  ['max_5fport_159',['MAX_PORT',['../group__syscalls.html#ga401e1a60d6381236216b6a130a6685bd',1,'tinyos.h']]],
  ['max_5fproc_160',['MAX_PROC',['../group__syscalls.html#ga63e32d00bc48471b4db49d481ac228dc',1,'tinyos.h']]],
  ['max_5fterminals_161',['MAX_TERMINALS',['../bios_8h.html#a4e7d162c7c35103b42768ff4a5c73905',1,'bios.h']]],
  ['max_5ftests_162',['MAX_TESTS',['../group__Testing.html#ga2a77d2f2c5b698c69c19e1f8782bf709',1,'unit_testing.h']]],
  ['minimum_5fcores_163',['minimum_cores',['../structTest.html#ac203918837b4c6718a020246e189a95a',1,'Test']]],
  ['minimum_5fterminals_164',['minimum_terminals',['../structTest.html#a2741188633c51b8e3cb545fa3971bf60',1,'Test']]],
  ['msg_165',['MSG',['../group__Testing.html#ga2e36933a48fbca44bb782f881ddceb20',1,'unit_testing.h']]],
  ['mutex_166',['Mutex',['../group__syscalls.html#gaef2ec62cae8e0031fd19fc8b91083ade',1,'tinyos.h']]],
  ['mutex_5finit_167',['MUTEX_INIT',['../group__syscalls.html#ga96be0bfc33e7e113099c7546798bec99',1,'tinyos.h']]],
  ['mutex_5flock_168',['Mutex_Lock',['../group__syscalls.html#ga1140be44df71d39edaf6a7262fb763ca',1,'Mutex_Lock(Mutex *lock):&#160;kernel_cc.c'],['../group__syscalls.html#ga1140be44df71d39edaf6a7262fb763ca',1,'Mutex_Lock(Mutex *):&#160;kernel_cc.c']]],
  ['mutex_5funlock_169',['Mutex_Unlock',['../group__syscalls.html#ga0b98d0315d0931d0c28104c36dd559c9',1,'Mutex_Unlock(Mutex *lock):&#160;kernel_cc.c'],['../group__syscalls.html#ga0b98d0315d0931d0c28104c36dd559c9',1,'Mutex_Unlock(Mutex *):&#160;kernel_cc.c']]],
  ['mx_170',['mx',['../structSymposiumTable.html#a8c36f26f523e6b2f99f6e70fff098de8',1,'SymposiumTable']]]
];
