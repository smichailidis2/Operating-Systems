var searchData=
[
  ['uint_589',['uint',['../bios_8h.html#a91ad9478d81a7aaf2593e8d9c3d06a14',1,'bios.h']]]
];
