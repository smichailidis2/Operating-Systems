var searchData=
[
  ['zombie_628',['ZOMBIE',['../group__proc.html#gga4f133ac5f9b2ca9c1446889baee1dc05a5dfb36109b24f39d54d5c3f48f53def8',1,'kernel_proc.h']]]
];
