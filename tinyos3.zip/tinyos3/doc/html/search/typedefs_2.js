var searchData=
[
  ['fcb_568',['FCB',['../group__streams.html#ga60c6c294fa1d8ea73ed270404fe5c17d',1,'FCB():&#160;kernel_streams.h'],['../group__rlists.html#ga60c6c294fa1d8ea73ed270404fe5c17d',1,'FCB():&#160;util.h']]],
  ['fid_5ft_569',['Fid_t',['../group__syscalls.html#ga5097222c5f0da97d92d4712359abc38f',1,'tinyos.h']]],
  ['file_5fops_570',['file_ops',['../group__dev.html#ga7f6c39ceb4960d7793f1740ad27f4783',1,'kernel_dev.h']]]
];
