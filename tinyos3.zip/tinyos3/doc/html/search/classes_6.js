var searchData=
[
  ['pipe_5fs_342',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock_343',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['procinfo_344',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments_345',['program_arguments',['../structprogram__arguments.html',1,'']]]
];
