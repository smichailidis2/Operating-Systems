var searchData=
[
  ['sendme_461',['sendme',['../group__Testing.html#ga0f97d30c4cd1370bcac6d7f4775d6789',1,'unit_testing.h']]],
  ['shutdown_462',['ShutDown',['../group__syscalls.html#ga61d49d63d8c0f9fc0917cc1bda6fdfcb',1,'tinyos.h']]],
  ['sleep_5freleasing_463',['sleep_releasing',['../group__scheduler.html#ga0ab1a2dcfbfe3fb09cc24044efddfd34',1,'sleep_releasing(Thread_state state, Mutex *mx, enum SCHED_CAUSE cause, TimerDuration timeout):&#160;kernel_sched.c'],['../group__scheduler.html#ga0ab1a2dcfbfe3fb09cc24044efddfd34',1,'sleep_releasing(Thread_state newstate, Mutex *mx, enum SCHED_CAUSE cause, TimerDuration timeout):&#160;kernel_sched.c']]],
  ['socket_464',['Socket',['../group__syscalls.html#gadf167321edde68e905173d8056d3eb2f',1,'tinyos.h']]],
  ['spawn_5fthread_465',['spawn_thread',['../group__scheduler.html#ga34517ad777ad754965f80fe0248c16e5',1,'spawn_thread(PCB *pcb, void(*func)()):&#160;kernel_sched.c'],['../group__scheduler.html#ga34517ad777ad754965f80fe0248c16e5',1,'spawn_thread(PCB *pcb, void(*func)()):&#160;kernel_sched.c']]],
  ['symposiumofprocesses_466',['SymposiumOfProcesses',['../symposium_8h.html#a528034fb39aa477a05b57211c9614ebe',1,'symposium.h']]],
  ['symposiumofthreads_467',['SymposiumOfThreads',['../symposium_8h.html#a5214bc7f5ae83c1db2e14b40dea86948',1,'symposium.h']]],
  ['symposiumtable_5fdestroy_468',['SymposiumTable_destroy',['../symposium_8h.html#af52cdc1038db2959d8af09fa5f13032f',1,'symposium.h']]],
  ['symposiumtable_5finit_469',['SymposiumTable_init',['../symposium_8h.html#acee238ec1bec29869630d48b21c54904',1,'symposium.h']]],
  ['symposiumtable_5fphilosopher_470',['SymposiumTable_philosopher',['../symposium_8h.html#ad0a96304b18eeb599ee43e14ed1c2e56',1,'symposium.h']]]
];
